module Wehbi_lab {
	requires java.xml;
	requires jdk.internal.le;
	requires jdk.jlink;
	requires org.apache.commons.io;
}